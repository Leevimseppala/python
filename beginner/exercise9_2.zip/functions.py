def show_personal_info():
    name = "Matti Meikälänen"
    home = "Sodankylä"
    job = "Ohjelmistosuunnittelija"
    print(name + "\n" + home + "\n" + job)

def count_seconds(hours, minutes, seconds):
    total = hours*3600+minutes*60+seconds
    return total

