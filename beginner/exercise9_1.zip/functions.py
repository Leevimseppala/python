def show_personal_info():
    name = "Matti Meikälänen"
    home = "Sodankylä"
    job = "Ohjelmistosuunnittelija"
    print(name + "\n" + home + "\n" + job)

    