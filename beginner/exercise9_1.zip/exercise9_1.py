from functions import show_personal_info


show_personal_info()